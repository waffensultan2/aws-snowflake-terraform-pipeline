def lambda_handler(event, context):
    print(event)

    return {
        "statusCode": 200
    }
